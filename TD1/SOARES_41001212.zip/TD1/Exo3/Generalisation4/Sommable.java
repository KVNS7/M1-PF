package Exo3.Generalisation4;

public interface Sommable<T>{
    T sommer(T autre);
}