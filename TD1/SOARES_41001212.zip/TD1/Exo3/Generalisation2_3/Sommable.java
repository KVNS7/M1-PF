package Exo3.Generalisation2_3;

public interface Sommable<T> {
    T sommer(T autre);
}

